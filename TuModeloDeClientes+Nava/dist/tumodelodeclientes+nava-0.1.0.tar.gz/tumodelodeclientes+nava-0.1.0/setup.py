from setuptools import setup, find_packages

setup(
    name="TuModeloDeClientes+Nava",
    version="0.1.0",
    packages=find_packages(),
    author="Rocio Nava",
    author_email="rocionavaserpa@gmail.com",
    description="Paquete redistribuible correspondiente al Trabajo Practico No. 2 de la clase de Python de Coderhouse",
    python_requires=">=3.6"
)